# Monitoring Exporters and Grafana Installation Guide

## Introduction

This guide provides step-by-step instructions for setting up monitoring exporters and Grafana for observability across various servers. The setup includes Node Exporter, Process Exporter, MySQL Exporter, Windows Exporter, JMX Exporter for Hazelcast, WildFly Exporter, and a Prometheus-Grafana stack deployment. Following this guide will ensure proper monitoring and visualization of system metrics, database performance, and application health.

### For clarity in these instructions, we use the following servers:

- `acs1`, `acs2`, `hc1`, `hc2`, `db`, `iis`

In this example, Prometheus is installed on the same server as the DB. You need to know its IP address during setup to whitelist it on the servers where the exporters are installed:

```
ACS1 - 65.109.58.164
ACS2 - 65.109.58.100
HC1  - 65.109.24.154
HC2  - 65.108.67.167
DB   - 65.109.58.165 <- PROMETHEUS_IP_HERE 
IIS  - 65.109.49.150
```

---

## 1. Install Docker and Docker Compose on All Debian/CentOS/Ubuntu Servers

**Target servers:** `acs1`, `acs2`, `hc1`, `hc2`, `db`

Before installing exporters, ensure that Docker and Docker Compose are installed on all target servers (except on Windows-based servers).

### Install Docker and Docker Compose

Run the following commands in the shell console of each target server:

#### If Ubuntu or Debian:

```bash
# Add Docker's official GPG key:
sudo apt-get update
sudo apt-get install ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings -y
sudo curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources:
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update

sleep 2

sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y
sudo systemctl enable docker --now
sudo systemctl status docker
```

#### If CentOS:

```bash
yum install -y yum-utils device-mapper-persistent-data lvm2 curl
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable docker
systemctl start docker
systemctl status docker
```

##### Ensure that everything works as expected:

Run the following commands in the server shell console:

```bash
docker -v
docker compose version
```

The result should look like:

```bash
[~] docker -v
Docker version 27.3.1, build ce12230
[~] docker compose version
Docker Compose version v2.29.7
```

---

## 2. Install Node Exporter and Process Exporter

**Target servers:** `acs1`, `acs2`, `hc1`, `hc2`, `db`, `iis`

We have two options for obtaining the necessary files: **download** the repository or **clone** it.

#### 2.1 Download

1. Open the repo [Friendly-Technologies/grafana](https://github.com/Friendly-Technologies/grafana) in your browser.
2. Click **Code** and select **Download ZIP**.
3. Copy `grafana-main.zip` to the `/opt` directory on the server and extract it:
   ```bash
   cd /opt && unzip grafana-main.zip -d /opt/grafana
   ```

#### 2.2 Clone

Run the following commands in the shell console:

```bash
cd /opt
git clone https://github.com/Friendly-Technologies/grafana.git
```

Enter your username and password if prompted (make sure you have access to this repo).

#### 2.3 File Structure

After downloading or cloning, you should have the following file structure:

```plaintext
/opt
└── grafana
    ├── nodes
    │   ├── centos
    │   │   ├── compose.yaml
    │   │   └── ...
    │   ├── ubuntu
    │   │   ├── compose.yaml
    │   │   └── ...
    │   ├── mysql
    │   │   ├── compose.yaml
    │   │   └── ...
    │   └── windows
    │       └── install_prerequirements.txt
    ├── prometheus-grafana-stack
    │   ├── compose.yaml
    │   ├── nginx.conf
    │   └── prometheus
    │       ├── hazelcast_rules.yml
    │       └── prometheus.yml
    └── README.md
```

Depending on the operating system, navigate to the relevant directory:

- For RHEL-based OS (CentOS/Red Hat):
  ```bash
  cd /opt/grafana/nodes/centos
  ```
- For Debian-based OS (Ubuntu/Debian):
  ```bash
  cd /opt/grafana/nodes/ubuntu
  ```

1. **Start the exporters** using Docker Compose:

   ```bash
   docker compose up -d
   ```

   **Hint:** You can check the logs of the started containers:

   ```bash
   docker compose logs -f
   ```

2. **Enable Prometheus to access exporter ports:**

   ```bash
   iptables -A INPUT -p tcp -s $PROMETHEUS_IP_HERE --dport 9100 -j ACCEPT
   iptables -A INPUT -p tcp -s $PROMETHEUS_IP_HERE --dport 9256 -j ACCEPT
   ```
   
   In our example we took ip address of prometheus and commands should be looking like that:
   
   ```bash
   iptables -A INPUT -p tcp -s 65.109.58.165 --dport 9100 -j ACCEPT
   iptables -A INPUT -p tcp -s 65.109.58.165 --dport 9256 -j ACCEPT
   ```

---

## 3. Install MySQL Exporter

**Target server:** `db`

Run the following commands in the shell console on the target server:

1. **Create an exporter user in MySQL:**

   Log in as `root` or `admin` and run the following commands (generate a secure password and replace `StR0nG_PassW0rD_hErE` accordingly):

   ```sql
   CREATE USER IF NOT EXISTS 'exporter'@'localhost' IDENTIFIED BY 'StR0nG_PassW0rD_hErE' WITH MAX_USER_CONNECTIONS 3;
   GRANT PROCESS, REPLICATION CLIENT, SELECT ON *.* TO 'exporter'@'localhost';
   ```

2. **Clone or download this repo** into `/opt/grafana`, in the same way as described in step 2.

3. **Modify the MySQL exporter credentials** in the file `/opt/grafana/nodes/mysql/compose.yaml`. Locate the line containing `mysqld.username=exporter:^13tkj%AR%vx83t,` and replace it with your credentials (for example, `mysqld.username=exporter:StR0nG_PassW0rD_hErE,`).

4. **Start the exporter** using Docker Compose:

   ```bash
   cd /opt/grafana/nodes/mysql/
   docker compose up -d
   ```

5. **Enable Prometheus to access exporter ports:**

   ```bash
   iptables -A INPUT -p tcp -s $PROMETHEUS_IP_HERE --dport 9104 -j ACCEPT
   ```

---

## 4. Install Windows Exporter

**Target server:** `iis`

### 4.1 Download and Install Windows Exporter

1. **Download the latest version of Windows Exporter:**

   - Go to: [Windows Exporter Releases](https://github.com/prometheus-community/windows_exporter/releases)
   - Download the latest installer (e.g., `windows_exporter-0.30.5-amd64.msi`) to the `C:\Users\Administrator\` folder.

2. **Run the installer:**

   - Press `Win + R`, type `cmd`, and press **Enter** to open Command Prompt.
   - Navigate to the folder where the file was downloaded or specify its full path:
     ```cmd
     msiexec /i "C:\Users\Administrator\windows_exporter-0.30.5-amd64.msi" ^
     ENABLED_COLLECTORS=ad,adfs,cache,cpu,cpu_info,cs,container,dfsr,dhcp,dns,fsrmquota,iis,logical_disk,logon,memory,msmq,mssql,netframework_clrexceptions,netframework_clrinterop,netframework_clrjit,netframework_clrloading,netframework_clrlocksandthreads,netframework_clrmemory,netframework_clrremoting,netframework_clrsecurity,net,os,process,remote_fx,service,tcp,time,vmware LISTEN_PORT=9182
     ```

### 4.2 Configure Windows Firewall

Ensure that the Prometheus server can access port `9182`:

1. **Open Command Prompt as Administrator.**
2. **Allow inbound traffic on port 9182:**
   ```cmd
   netsh advfirewall firewall add rule name="Allow Windows Exporter" dir=in action=allow protocol=TCP localport=9182
   ```
3. **Verify that the service is running:**
   ```cmd
   sc query windows_exporter
   ```
4. **Test the exporter** by opening a web browser and navigating to:
   ```
   http://<server-ip>:9182/metrics
   ```
   You should see the Prometheus metrics.

---

## 5. Install JMX Exporter for Hazelcast Servers Only

**Target servers:** `hc1`, `hc2`

Run the following commands in the shell console on each target server:

1. **Edit the Hazelcast startup script:**

   Add the following to the beginning of `/usr/local/hazelcast-5.0/bin/hz-start`:

   ```bash
   #!/bin/bash
   export PROMETHEUS_PORT=9101
   ```

2. **Edit the JMX Agent configuration file:**

   Update `/usr/local/hazelcast-5.0/config/jmx_agent_config.yaml` with:

   ```yaml
   ssl: false
   rules:
     - pattern: ".*"
   ```

3. **Restart Hazelcast:**

   ```bash
   service hazelcast5 restart
   ```

4. **Enable Prometheus to access exporter ports:**

   ```bash
   iptables -A INPUT -p tcp -s $PROMETHEUS_IP_HERE --dport 9101 -j ACCEPT
   ```

---

## 6. Install WildFly Exporter (JBoss) for ACS Servers Only

**Target servers:** `acs1`, `acs2`

Run the following commands in the shell console on each target server:

1. **Add the WildFly exporter module:**

   ```bash
   cd /usr/local/FTACS/modules/system/layers/base
   wget https://repo1.maven.org/maven2/nl/nlighten/wildfly_exporter_module/0.0.5/wildfly_exporter_module-0.0.5.jar
   unzip wildfly_exporter_module-0.0.5.jar
   rm -rf META-INF wildfly_exporter_module-0.0.5.jar
   ```

2. **Enable the WildFly module via JBoss CLI:**

   ```bash
   /usr/local/FTACS/bin/jboss-cli.sh
   connect
   /subsystem=ee/:write-attribute(name=global-modules,value=[{"name" => "nl.nlighten.prometheus.wildfly", "meta-inf" => "true", "services" => "true"}])
   ```

3. **Download the WildFly exporter servlet:**

   ```bash
   wget https://repo1.maven.org/maven2/nl/nlighten/wildfly_exporter_servlet/0.0.5/wildfly_exporter_servlet-0.0.5.war -O /usr/local/FTACS/standalone/deployments/metrics.war
   ```

4. **Enable statistics and reload WildFly:**

   ```bash
   /usr/local/FTACS/bin/jboss-cli.sh
   connect
   /subsystem=undertow:write-attribute(name=statistics-enabled, value=true)
   /subsystem=datasources:read-resource(recursive=true)
   /subsystem=datasources/data-source=FTDS:write-attribute(name=statistics-enabled,value=true)
   :reload
   ```

5. **Enable Prometheus to access the WildFly exporter port (8080):**

   ```bash
   iptables -A INPUT -p tcp -s $PROMETHEUS_IP_HERE --dport 8080 -j ACCEPT
   ```

---

## 7. Configure and Deploy Prometheus with Grafana

**Target server:** `db` (or separate server dedicated for Grafana only)

In this example, we are using the `db` server to host Grafana and Prometheus, but there is no strict requirement—it can be any server that suits your environment.

Please follow the official page to observe hardware requirements https://grafana.com/docs/enterprise-traces/latest/setup/hardware-requirements/

Note: for the small-scale setup (up to 10 server nodes) here is enough 4 CPU and 8 RAM.


1. **Clone or download this repo** into `/opt/grafana`, as described previously. Edit the file `/opt/grafana/prometheus-grafana-stack/prometheus/prometheus.yml`.

   - For each `node-exporter` section, fill in the IP addresses of the servers (only the IP; do **not** change the port).
   - Set a server name for display on Grafana’s graphs; it does not have to match the actual hostname.
   - **Important**: Ensure the server name includes a pattern (like `DB`, `ACS`, or `HC`) to match the Grafana regex filter `.*(ACS|DB|HC).*`.

2. **Configure environment variables for Grafana** in `/opt/grafana/prometheus-grafana-stack/compose.yaml`:

   ```yaml
   environment:
     - GF_SERVER_ROOT_URL=http://65.109.58.165:3000/
     - GF_SERVER_ALLOW_ORIGIN=http://65.109.58.165:3030
     - GF_LIVE_ALLOWED_ORIGINS=http://65.109.58.165:3030
     - GF_SECURITY_ADMIN_USER=admin
     - GF_SECURITY_ADMIN_PASSWORD=grafana!@#
     - GF_SMTP_ENABLED=true
     - GF_SMTP_HOST=smtp.mailgun.org:587
     - GF_SMTP_USER=postmaster@sandboxe94eb72b5ae64385887e7baf08e693bb.mailgun.org
     - GF_SMTP_PASSWORD=fbf88d3985221887252a633e9155c497-f6fe91d3-15c2e61d
     - GF_SECURITY_ALLOW_EMBEDDING=true
     - GF_DASHBOARDS_JSON_ENABLED=true
     - GF_DASHBOARDS_CUSTOM_CSS=/etc/grafana/provisioning/dashboards/custom.css
   ```

### Explanation of the Parameters

| **Variable**                  | **Description**                                                                                                                                               |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `GF_SERVER_ROOT_URL`          | The root URL of the Grafana instance, used to generate correct links in the UI.                                                                               |
| `GF_SERVER_ALLOW_ORIGIN`      | Specifies the allowed origin for CORS (Cross-Origin Resource Sharing). This is useful when embedding Grafana panels or accessing APIs from different domains. |
| `GF_LIVE_ALLOWED_ORIGINS`     | Defines the allowed origins for WebSocket connections, primarily used by Grafana Live features.                                                               |
| `GF_SECURITY_ADMIN_USER`      | Sets the admin username for Grafana authentication.                                                                                                           |
| `GF_SECURITY_ADMIN_PASSWORD`  | Sets the admin password for Grafana authentication.                                                                                                           |
| `GF_SMTP_ENABLED`             | Enables SMTP (email) notifications in Grafana. (`true` = enabled). Must be provided by the client.                                                            |
| `GF_SMTP_HOST`                | The SMTP server address and port for sending emails (e.g., alerts, notifications). Must be provided by the client.                                            |
| `GF_SMTP_USER`                | The username for the SMTP server (usually an email address). Must be provided by the client.                                                                  |
| `GF_SMTP_PASSWORD`            | The password or API key for the SMTP server. Must be provided by the client.                                                                                  |
| `GF_SECURITY_ALLOW_EMBEDDING` | Allows embedding Grafana dashboards in iframes (`true` = enabled).                                                                                            |
| `GF_DASHBOARDS_JSON_ENABLED`  | Enables JSON-based dashboard provisioning, allowing predefined dashboards to be loaded from JSON files.                                                       |
| `GF_DASHBOARDS_CUSTOM_CSS`    | Specifies a custom CSS file path to apply custom styling to the Grafana UI.                                                                                   |

3. **Start the Prometheus-Grafana stack:**

   ```bash
   cd /opt/grafana/prometheus-grafana-stack
   docker compose up -d
   ```

4. **Enable access to Grafana and Prometheus ports:**

   ```bash
   iptables -A INPUT -p tcp --dport 9090 -j ACCEPT
   iptables -A INPUT -p tcp --dport 3000 -j ACCEPT
   iptables -A INPUT -p tcp --dport 3030 -j ACCEPT
   ```

5. **Test the setup:**

   - Prometheus: [http://grafana\_ip:9090/targets?search=](http://grafana_ip:9090/targets?search=)
   - Grafana: [http://grafana\_ip:3000/dashboards](http://grafana_ip:3000/dashboards)

6. **Enable a read-only reverse proxy for embedding in a Friendly application:**

   1. Open **http\://grafana\_ip:3000/org/serviceaccounts** and click **Add service account**.

   2. Set **Display name** to `ReadOnlySA` and **Role** to `Viewer`, then click **Create**.

   3. In the **Tokens** section, click **Add service account token**, set **Display name** to `nginx_ro`, and generate the token. Copy the token for the next steps.

   4. On the server where Grafana is installed, edit `/opt/grafana/prometheus-grafana-stack/nginx.conf`.

   5. Replace the placeholder token `glsa_KXrHyHUaxqntEMUJKxnmyNlAGjwjphr1_ce051982` with your newly created `nginx_ro` token.

   6. Replace the placeholder IP `65.109.58.165` with your actual Grafana IP.

   7. **Configure Alerting**: Update the email `georgek.122@gmail.com` in `/opt/grafana/prometheus-grafana-stack/grafana/provisioning/alerting/alert_resources.yaml` with your own email(s). Multiple emails can be separated by `;`, `\n`, or `,`.

   8. **Apply all changes**:

      ```bash
      cd /opt/grafana/prometheus-grafana-stack
      docker compose down
      docker compose up -d
      ```

7. **Test the Nginx reverse proxy**:

   Open **http\://grafana\_ip:3030/** — you should see Grafana dashboards without needing to log in, with read-only permissions.

---

## Grafana User Management

For more details on user management, refer to the official documentation:\
[Grafana User Management](https://grafana.com/docs/grafana/latest/administration/user-management/)

---
